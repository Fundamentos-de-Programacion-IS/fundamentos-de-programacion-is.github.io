"""Simulacro 0 — Carrera de tortugas.  (No puntúa.)

Completa las cuatro funciones. NO cambies los nombres de las funciones ni los de los
campos de `Participacion`: el corrector los busca por nombre.

Puedes añadir todas las funciones auxiliares que quieras.
"""

import csv
from typing import NamedTuple


Participacion = NamedTuple("Participacion", [
    ("carrera", str),
    ("distancia", int),
    ("tortuga", str),
    ("velocidad", int),
])


def lee_participaciones(ruta: str) -> list:
    """Lee el CSV de carreras y devuelve una lista de `Participacion`, en el orden del fichero.

    - La primera línea es la cabecera.
    - `distancia` y `velocidad` son enteros.
    """
    raise NotImplementedError


def vueltas_hasta_meta(velocidad: int, distancia: int) -> int:
    """Número de vueltas que tarda una tortuga en alcanzar o superar `distancia`
    si en cada vuelta avanza `velocidad`.

    Lanza `ValueError` si la velocidad no es positiva.
    """
    raise NotImplementedError


def ganadora(participaciones: list, carrera: str) -> str:
    """Nombre de la tortuga que llega a la meta de `carrera` en menos vueltas.

    - Si varias llegan en esa misma vuelta, devuelve "empate".
    - Las tortugas con velocidad 0 o negativa no corren.
    - Lanza `ValueError` si en esa carrera no corre ninguna tortuga.
    """
    raise NotImplementedError


def victorias(participaciones: list) -> dict:
    """Diccionario {tortuga: número de carreras que ha ganado}.

    Los empates no cuentan como victoria. Sólo aparecen las tortugas que han
    ganado al menos una carrera.
    """
    raise NotImplementedError


if __name__ == "__main__":
    participaciones = lee_participaciones("data/carreras.csv")
    print(len(participaciones), participaciones[0])
    print(vueltas_hasta_meta(12, 620))
    print(ganadora(participaciones, "jardin"))
    print(victorias(participaciones))
